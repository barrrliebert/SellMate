<?php echo e($slot); ?>

<?php /**PATH C:\Users\Kyzee\Documents\2025 project\Februari\pkl-1\project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>