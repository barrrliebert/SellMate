1. clone repository
2. sesuaikan .env konfigurasi db nya
3. composer install
4. php artisan key:generate
5. npm install 
6. npm run dev (pastikan selalu dijalankan diterminal)
7. php artisan migrate:fresh --seed
8. php artisan serve (pastikan selalu dijalankan diterminal)
composer require barryvdh/laravel-dompdf
php artisan vendor:publish --provider="Barryvdh\DomPDF\ServiceProvider"
php artisan storage:link
